###############################################################################
#
# Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
#
# The code contained herein is the proprietary and confidential information
# of Cadence or its licensors, and is supplied subject to a previously
# executed license and maintenance agreement between Cadence and customer.
# This code is intended for use with Cadence high-level synthesis tools and
# may not be used with other high-level synthesis tools. Permission is only
# granted to distribute the code as indicated. Cadence grants permission for
# customer to distribute a copy of this code to any partner to aid in designing
# or verifying the customer's intellectual property, as long as such
# distribution includes a restriction of no additional distributions from the
# partner, unless the partner receives permission directly from Cadence.
#
# ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
# FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
# LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
# INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
# INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
# CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
#
################################################################################

# The functions defined here are used to re-shape the weights and
# biases of various NN layers. The re-shaped data is dumped into text
# files, which are input to the SystemC HLS models of the layers.

# Reshaping is required to correctly group the weights and biases as
# needed by the HLS archiecture.

# For example, the conv2d function expects the filter tensor to be in
# the shape:

# [filter_height, filter_width, in_channels, out_channels].

# For C++, each filter is an object that holds an array of
# coefficients, with the shape [filter_height, filter_width]. There
# are a total of (out_channels*in_channels) filter objects. In order
# to read the coefficients from a stream, they must be dumped so that
# the coefficients for each filter are in sequence. 

# For the fully connected layers (matmul), the matrix needs to be
# re-grouped into NUM_OUT*NUM_IN sized blocks, where NUM_OUT and
# NUM_IN are the number of parallel outputs/inputs for that
# layer. These properties are specific to that layer (e.g. the FCL may
# be 32x32 and the OL may be 32x10) and depend on the chosen HLS
# archiecture.

# If the input is a 1-D array (e.g. bias values), the output is just
# all the elements in order.

import numpy

# Define specialized converter functions for specific types of blocks

def convert_conv2d(name, arr): 
    print("Converting conv2d weights for ", name, ", array shape:", numpy.shape(arr))
    if (len(numpy.shape(arr)) == 4):
        # 4-D array for convolution filter
        # Get each nxn filter from the nxnxINxOUT array
        t = numpy.zeros([ (arr.shape[3]*arr.shape[2]), arr.shape[0], arr.shape[1] ])
        index = 0
        for o in range(arr.shape[3]):
            for i in range(arr.shape[2]):
                x = arr[:, :, i, o]
                filter = x.copy()
                #print("filter i=", i, ", o=", o, ", shape = ", numpy.shape(filter), ", value = \n", filter)
                t[index] = filter
                index = index + 1
        result = t
        
    else:
        print("ERROR: convert_conv2d: Input data does not have the correct shape. Expeced 4-D tensor, got ", numpy.shape(arr))
        result = None
    return result

def convert_matmul(name, arr, num_out, num_in): 
    print("Converting matmul weights for ", name, ", array shape:", numpy.shape(arr), ", num_out ", num_out, ", num_in ", num_in)
    if (len(numpy.shape(arr)) == 2):

        # The input array is the weight matrix for the dense
        # layers. This is of size R x C. This needs to be shaped into
        # a set of num_out x num_in sized chunks. The chunks are
        # traversed top-to-bottom and left-to-right within the larger
        # array. Inside each chunk, the data is orderd in the same way
        # (i.e. column-major order).

        nr = arr.shape[0]
        nc = arr.shape[1]
        if (nc % num_out != 0):
            print("ERROR: convert_matmul: num_out(", num_out, ") does not divide number of columns (", nc, ") evenly.")
            return None
        if (nr % num_in != 0):
            print("ERROR: convert_matmul: num_in(", num_in, ") does not divide number of rows (", nr, ") evenly.")
            return None

        outchunks = int(nc/num_out)
        inchunks = int(nr/num_in)
        nchunks = int(outchunks*inchunks)
        temp_result = numpy.zeros(int(nr*nc))
        chunk = -1
        x = 0 
        for i in range(outchunks):
            for j in range(inchunks):
                chunk = chunk + 1
                for k in range(num_out):
                    for l in range(num_in):
                        row = j*num_in + l
                        col = i*num_out + k
                        index = row * nc + col;
                        temp_result[x] = arr[row][col]
                        # print(name, ": x ", x, ",i " ,i ,", j " ,j ,", k " ,k ,", l " ,l ,", row " ,row ,", col " ,col ,", index " ,index ,", value " , arr[row][col])
                        x = x + 1

        result = temp_result.copy()

    else:

        print("ERROR: convert_matmul: Input data does not have the correct shape. Expeced 2-D matrix, got ", numpy.shape(arr))
        result = None

    return result


