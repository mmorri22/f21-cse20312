# Example Convolutional Neural Network, developed for use with the Stratus HLS Machine Learning RAK.

import os
import sys
import argparse
import math
import numpy

# Requires version 2.1 of TensorFlow

import tensorflow as tf
tf.compat.v1.disable_eager_execution()

# Turn off some unnecessary messages
os.environ['KMP_WARNINGS'] = '0'
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '3'
tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)


###############################################################################
# Initialization
###############################################################################

# Command-line parsing

parser = argparse.ArgumentParser(description=('Convolutional Neural Network for recognizing the MNIST hand-written digit dataset. '
                                 +'The associated Stratus HLS project synthesizes the network into hardware.'))

parser.add_argument('--train', action='store_true',
                    help=('Train the network on the MNIST training dataset (start with random coefficients). '
                          +'The network is saved for later reuse. '))
parser.add_argument('--test', action='store_true',
                    help=('Test the network against the MNIST test dataset. '
                          +'If --train is specified, train the network first; otherwise restore the previously trained network. '))
parser.add_argument('--export', action='store',
                    help=('Export the coefficients and test image data in text format, suitable for reading by the testbench module in the Stratus HLS project. '
                          +'The exported data is placed in the directory EXPORT, with two subdirectories Weights and Tests. '))
parser.add_argument('--seed', action='store', default=None, type=float,
                    help=('Seed for the random number generators used to initialize the weights and biases during training. '
                          +'Re-training with the same seed yields the same network. '))

args = parser.parse_args()

# Filesystem

path = os.getcwd()
model_file = path + '/trained_model/trained_model'

# Seeds for repeatable training

main_seed = args.seed
seeds = [None for x in range(9)]

if (main_seed) :
    tf.compat.v1.random.set_random_seed(main_seed)
    seeds = numpy.arange(start=(main_seed+1), stop=(main_seed+10), step=1)
    print ("Setting main seed = ", main_seed, ", operation seeds = ", seeds)

# Load MNIST data

n_classes = 10

# print ('Loading MNIST data')

mnist_data = tf.keras.datasets.mnist.load_data()

((orig_train_images, orig_train_labels), (orig_test_images, orig_test_labels)) = mnist_data

num_train_images = numpy.shape(orig_train_images)[0]
num_test_images = numpy.shape(orig_test_images)[0]

# The image data is integers in range [0, 255], need to rescale to floats [0.0, 1.0]

train_images = orig_train_images.astype(numpy.float32)
train_images = numpy.multiply(train_images, 1.0 / 255.0)

test_images = orig_test_images.astype(numpy.float32)
test_images = numpy.multiply(test_images, 1.0 / 255.0)

# The labels need to be expanded to one-hot arrays of size 10

index_offset = numpy.arange(num_train_images) * n_classes
train_labels = numpy.zeros((num_train_images, n_classes))
train_labels.flat[index_offset + orig_train_labels.ravel()] = 1

index_offset = numpy.arange(num_test_images) * n_classes
test_labels = numpy.zeros((num_test_images, n_classes))
test_labels.flat[index_offset + orig_test_labels.ravel()] = 1

###############################################################################
# Network Graph Definition
###############################################################################

# Define the CNN. The various sizes are hard-coded

# Constants

batch_size = 128
dropout_rate = 0.2
learning_rate = 0.001

img_width = 28
img_height = 28

# Placeholders for data I/O
cnn_input = tf.compat.v1.placeholder('float', [None, img_width, img_height], name='cnn_input')
expected_output = tf.compat.v1.placeholder('float', name='expected_output')

# TF variables for weights and biases
w_and_b = {'w_Conv1':tf.Variable(tf.random.normal([3,3,1,16], seed=seeds[0]), name='w_Conv1'),
           'b_Conv1':tf.Variable(tf.random.normal([16], seed=seeds[1]), name='b_Conv1'),
           'w_Conv2':tf.Variable(tf.random.normal([3,3,16,32], seed=seeds[2]), name='w_Conv2'),
           'b_Conv2':tf.Variable(tf.random.normal([32], seed=seeds[3]), name='b_Conv2'),
           'w_FCL':tf.Variable(tf.random.normal([7*7*32,1024], seed=seeds[4]), name='w_FCL'),
           'b_FCL':tf.Variable(tf.random.normal([1024], seed=seeds[5]), name='b_FCL'),
           'w_OL':tf.Variable(tf.random.normal([1024, n_classes], seed=seeds[6]), name='w_OL'),
           'b_OL':tf.Variable(tf.random.normal([n_classes], seed=seeds[7]), name='b_OL')}

# CNN Layers

# Convolution 1

t0 = tf.reshape(cnn_input, shape=[-1, img_width, img_height, 1])
t1 = tf.nn.conv2d(input=t0, filters=w_and_b['w_Conv1'], strides=[1,1,1,1], padding='SAME')
t2 = t1 + w_and_b['b_Conv1']
Conv1_out = tf.nn.relu(t2, name='Conv1_out')

# Max Pool 1

Pool1_out = tf.nn.max_pool2d(Conv1_out, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME', name='Pool1_out')

# Convolution 2

t3 = tf.nn.conv2d(input=Pool1_out, filters=w_and_b['w_Conv2'], strides=[1,1,1,1], padding='SAME')
t4 = t3 + w_and_b['b_Conv2']
Conv2_out = tf.nn.relu(t4, name='Conv2_out')

# Max Pool 2

Pool2_out = tf.nn.max_pool2d(Conv2_out, ksize=[1,2,2,1], strides=[1,2,2,1], padding='SAME', name='Pool2_out')

# Fully Connected Layer

FCL_in = tf.reshape(Pool2_out, [-1, 7*7*32])
t5 = tf.matmul(FCL_in, w_and_b['w_FCL'])
t6 = t5 + w_and_b['b_FCL']
t7 = tf.nn.relu(t6)
FCL_out = tf.nn.dropout(t7, rate=dropout_rate, seed=seeds[8], name='FCL_out')

# Output layer

t8 = tf.matmul(FCL_out, w_and_b['w_OL'])
OL_out = t8 + w_and_b['b_OL']

# Final prediction
prediction = tf.nn.softmax(OL_out, name='prediction')

# Training operations
cost = tf.reduce_mean( input_tensor=tf.nn.softmax_cross_entropy_with_logits(logits=OL_out,labels=expected_output) )
optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate).minimize(cost)

# Accuracy measurement
correct = tf.equal(tf.argmax(input=OL_out, axis=1), tf.argmax(input=expected_output, axis=1), name='correct')
accuracy = tf.reduce_mean(input_tensor=tf.cast(correct, 'float'), name='accuracy')

# Save/Restore
saver = tf.compat.v1.train.Saver()

# End of CNN definition

###############################################################################
# Converters for HLS data
###############################################################################

# Data conversion table for exporting weights into text files,
# suitable for reading by the Stratus HLS modules. For more details
# see the export section below.

import convert  # Local file, contains conversion functions for specific layer types

# Note: the hard-coded parameters for each conversion are the same as the settings used for the HLS modules.

converters = { 'w_Conv1' : (lambda name, arr : convert.convert_conv2d(name, arr)),
               'w_Conv2' : (lambda name, arr : convert.convert_conv2d(name, arr)),
               'w_FCL' : (lambda name, arr : convert.convert_matmul(name, arr, 32, 32)),
               'w_OL' : (lambda name, arr : convert.convert_matmul(name, arr, 10, 32)),
             }

###############################################################################
# TensorFlow Session: Training, Testing and Export
###############################################################################

with tf.compat.v1.Session() as sess:

    # Initialize all variables
    sess.run(tf.compat.v1.global_variables_initializer())

    ###########################################################################
    # Training
    ###########################################################################

    if (args.train) :

        num_batches = math.ceil(num_train_images/batch_size)

        print ('Training started, num_train_images = ', num_train_images, ', num_batches = ', num_batches)

        num_epochs = 15
        for epoch in range(num_epochs):

            epoch_loss = 0
            start = 0

            for batch in range(num_batches):
                end = start + batch_size

                epoch_images = train_images[start:end]
                epoch_labels = train_labels[start:end]

                start = start + batch_size

                foo, c = sess.run([optimizer, cost], feed_dict={cnn_input: epoch_images, expected_output: epoch_labels})

                epoch_loss += c
                
            print('Epoch', epoch, 'completed out of',num_epochs,'loss:',epoch_loss)

        # Check accuracy over training data
        result = sess.run(accuracy, feed_dict={cnn_input: train_images, expected_output: train_labels});
        print('Accuracy over training data:', result)

        # Check accuracy over test data
        result = sess.run(accuracy, feed_dict={cnn_input: test_images, expected_output: test_labels});
        print('Accuracy over test data:', result)

        # Save the model to disk.
        save_path = saver.save(sess, model_file)
        print('Trained model saved in path: ', model_file)

    else :
        # did not train, restore from saved model

        if os.path.isfile(model_file + '.index' ):

            print('Restoring trained model from path: ', model_file)
            saver.restore(sess, model_file)
            print('Model restored.')

        else:

            print('Could not find model to restore (path ', model_file, ')\nPlease use --train to create a new one first.')
            sys.exit(1)

    ###########################################################################
    # Testing
    ###########################################################################

    if (args.test) :

        # Test and get accuracy
        result = sess.run(accuracy, feed_dict={cnn_input: test_images, expected_output: test_labels})
        print('Test Accuracy:', result)

    ###########################################################################
    # Export data to HLS model
    ###########################################################################

    if (args.export != None) :

        # Export network coefficients to the export directory. All the
        # variables are in the w_and_b list.

        # The output text files are not in the same order/shape as the
        # Numpy arrays. Reshaping is required to correctly group the
        # weights and biases as needed by the HLS archiecture. The
        # requirement is for the C++ code to read a text file in
        # linear order and fill the various weight/bias arrays in the
        # correct sequence.

        # For example, the conv2d function expects the filter tensor to be in
        # the shape:

        # [filter_height, filter_width, in_channels, out_channels].

        # For C++, each filter is an object that holds an array of
        # coefficients, with the shape [filter_width, filter_height]. There
        # are a total of (out_channels*in_channels) filter objects. In order
        # to read the coefficients from a stream, they must be dumped so that
        # the coefficients for each filter are in sequence. This requires
        # re-shaping the 4-D array: transpose, and then swap the last two
        # axes.

        # For the fully connected layers (matmul), the matrix needs to
        # be re-grouped into NUM_OUT*NUM_IN sized blocks, where
        # NUM_OUT and NUM_IN are the number of parallel outputs/inputs
        # for that layer. These properties are
        # specific to that layer (e.g. the FCL may be 32x32 and the OL
        # may be 32x10) and depend on the chosen HLS archiecture.

        # If the input is a 1-D array (e.g. bias values), the output is just
        # all the elements in order.

        # The actual conversion functions are defined in the file
        # convert.py, one for each type of layer. The functions are
        # called via the 'converters' table, defined above, which
        # links the name of a layer with the appropriate conversion
        # function and its parameters.

        export_base = path + '/' + args.export
        export_path = export_base + '/Weights'

        print ('Exporting network coefficients to ', export_path)

        os.makedirs(export_path, exist_ok=True)
        
        for name, var in w_and_b.items() :
            # Note that var is a TensorFlow Variable object. We need the Numpy array inside it.
            arr = var.eval()
            # Re-shape the array if a converter is specified for it, otherwise dump it as-is
            #print('array ', name, ', shape ', numpy.shape(arr), ', value = \n', str(arr))
            
            if name in converters:
                #print('Calling converter for ', name)
                converted_arr = converters[name](name, arr)
            else:
                #print('NOT calling converter for ', name)
                converted_arr = arr

            filename = export_path + '/' + name + '.txt'
            print('Saving ', name, ' to ', filename)
            converted_arr.tofile(filename, '\n', '%.18e')

        #######################################################################
        # Also export the test images and test labels into the tests
        # directory.
        #######################################################################

        test_path = export_base + '/Tests'
        print ('Exporting test images to ', test_path)

        os.makedirs(test_path, exist_ok=True)

        # Labels are the golden results, for comparison against NN results
        filename = test_path  + '/labels.txt'
        orig_test_labels.tofile(filename, '\n')

        for i in range(num_test_images) :
            test = test_images[i]
            filename = test_path  + '/' + str(i) + '.txt'
            #print("Writing test #", i, " to file ", filename)
            test.tofile(filename, '\n', '%.18e')

        
print ('All done.')

sys.exit(0)