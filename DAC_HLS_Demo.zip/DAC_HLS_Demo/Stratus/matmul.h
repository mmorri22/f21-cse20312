///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "settings.h"

#include "cynw_p2p.h"
#include "array_mac.h"

template <typename SETTINGS>
class matmul : public sc_module
{
public:
    // typedefs/constants from settings class

    typedef typename SETTINGS::DT_BIASVAL    biasval_type;
    typedef typename SETTINGS::DT_WEIGHTVAL  weightval_type;

    typedef typename SETTINGS::DT_BIAS   bias_type;
    typedef typename SETTINGS::DT_WEIGHT weight_type;

    typedef typename SETTINGS::DT_INVAL  inval_type;
    typedef typename SETTINGS::DT_OUTVAL outval_type;

    typedef typename SETTINGS::DT_INPUT  input_type;
    typedef typename SETTINGS::DT_OUTPUT output_type;

    static const unsigned IN_ROWS = SETTINGS::IN_ROWS;
    static const unsigned IN_COLS = SETTINGS::IN_COLS;
    static const unsigned IN_SIZE = (IN_ROWS)*(IN_COLS);

    static const unsigned OUT_ROWS = IN_ROWS; // always the same
    static const unsigned OUT_COLS = SETTINGS::OUT_COLS;
    static const unsigned OUT_SIZE = (OUT_ROWS)*(OUT_COLS);

    // The number of parallel inputs and outputs received/sent at once.
    static const unsigned NUM_IN = SETTINGS::NUM_IN;
    static const unsigned NUM_OUT = SETTINGS::NUM_OUT;

    static const unsigned IN_CHUNKS = IN_COLS/NUM_IN;
    static const unsigned OUT_CHUNKS = OUT_COLS/NUM_OUT;

    static const bool DO_RELU = SETTINGS::DO_RELU;

    SC_HAS_PROCESS(matmul);

    // Declare the clock and reset ports
    sc_in_clk clk;
    sc_in < bool > rst;

    // weights and biases are input via p2p
    typename cynw_p2p < weight_type, ioConfig >::in w; // The input port for W
    typename cynw_p2p < bias_type, ioConfig >::in b; // The input port for B

    typename cynw_p2p < input_type, ioConfig >::in in; // The input port for data
    typename cynw_p2p < output_type, ioConfig >::out out; // The output port

    // The entire input matrix needs to be stored locally.

    inval_type  input[IN_ROWS][IN_COLS];
            
    //SC_CTOR( matmul )
    matmul( sc_module_name name =
            sc_module_name( sc_gen_unique_name("matmul") ) )
        : sc_module(name)

        , clk( "clk" )
        , rst( "rst" )
        , w( "w")
        , b( "b")
        , in( "in" )
        , out( "out" )
        {
            SC_CTHREAD( matmul_thread, clk.pos() );
            set_stack_size(0x100000000);
            reset_signal_is( rst, 0 );
            set_stack_size(0x100000000);
            // Connect the clk and rst signals to the modular interface ports
            in.clk_rst( clk, rst );
            out.clk_rst( clk, rst );
            w.clk_rst( clk, rst );
            b.clk_rst( clk, rst );

            HLS_MAP_TO_MEMORY(input);

        }

    // main thread
    void matmul_thread()
        {

            // size checks
            assert((IN_ROWS == OUT_ROWS));
            assert(((IN_COLS % NUM_IN) == 0));
            assert(((OUT_COLS % NUM_OUT) == 0));

            // reset the interfaces
            {
                HLS_DEFINE_PROTOCOL( "reset" );
                in.reset();
                out.reset();
                w.reset();
                b.reset();

                wait();
            }

            while( 1 ) {
                unsigned row, ic, oc;

                // loop over rows of the matrix
                for (row = 0; row < IN_ROWS; row++) {
                    HLS_UNROLL_LOOP(OFF, "in_rows loop");
                        
                    input_type d_in;
                    output_type d_out;
                    outval_type oval;
                    weight_type w_in;
                    bias_type b_in;

                    // for each row, loop over output chunks
                    for (oc = 0; oc < OUT_CHUNKS; oc++) {
                        HLS_UNROLL_LOOP(OFF, "out_chunks loop");
                        
                        // Read one set of bias values per output
                        // chunk per row.
                        b_in = b.get();

                        // Loop over input chunks. Each input chunk
                        // contains NUM_IN data values for one row,
                        // corresponding to columns in the range
                        // (ic : ic+NUM_IN-1). Inputs are received only
                        // once so they need to be stored locally for
                        // use when oc > 0.

                        for (ic = 0; ic < IN_CHUNKS; ic++) {
                            
                            // Note: this loop (and the two parent
                            // loops) are not unrolled; all inner
                            // loops are unrolled via the global
                            // attribute.

                            HLS_UNROLL_LOOP(OFF, "in_chunks loop");
                            // Different latency constraints for
                            // performance trade-offs.
#if defined(FAST)
                            HLS_CONSTRAIN_LATENCY(0, HLS_ACHIEVABLE, "mac_loop_latency_fast");
#elif defined(MEDIUM)
                            // Need NUM_IN cycles to read the input from memory, and NUM_OUT cycles to spread out the computations
                            HLS_CONSTRAIN_LATENCY(0, (NUM_IN + NUM_OUT), "mac_loop_latency_medium");
#else
                            HLS_CONSTRAIN_LATENCY("mac_loop_latency_slow"); // unconstrained, only report the latency
#endif
                            // read one set of weights per output
                            // chunk per input chunk.

                            w_in = w.get();

                            const unsigned icaddr = (ic*NUM_IN);
                            
                            if (oc == 0) {
                                // read data input chunk for the first
                                // time, store in input array.
                                d_in = in.get();

                                for (unsigned i = 0; i < NUM_IN; i++) {
                                    input[row][icaddr+i] = d_in[i];
                                }
                            } else {
                                // use previosly stored input chunk.
                                for (unsigned i = 0; i < NUM_IN; i++) {
                                    d_in[i] = input[row][icaddr+i];
                                }
                            }

                            // multiply and accumulate the output chunk.
                            for (unsigned o = 0; o < NUM_OUT; o++) {

                                outval_type oval;
                                // need local copies of the input and weights arrays.
                                inval_type in1[NUM_IN];
                                weightval_type in2[NUM_IN];

                                for (unsigned i = 0; i < NUM_IN; i++) {
                                    in1[i] = d_in[i];
                                    in2[i] = w_in.weights[o][i][0][0];
                                }

                                oval = array_mac<NUM_IN, outval_type, inval_type, weightval_type>::mac(in1, in2);

                                d_out[o] += oval;
                            }
                        }

                        // one chunk of the output is complete, add bias
                        // to current chunk and produce output.

                        for (unsigned o = 0; o < NUM_OUT; o++) {
                            outval_type oval;

                            d_out[o] = d_out[o] + b_in.bias[o];

                            if (DO_RELU) {
                                // ReLU Activation Function
                                if (d_out[o] < 0)
                                    d_out[o] = 0;
                            }
                        }

                        out.put(d_out);
                    }
                }
            }
        }

};

