///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "stratus_hls.h"

template < typename DT, unsigned S, unsigned DTBITS > 
class data_array
{
    public:

    DT p[S];

    data_array()
    {
        HLS_FLATTEN_ARRAY(p);
    }

    data_array(DT pi[S])
    {   HLS_FLATTEN_ARRAY(p);
        for (unsigned i=0;i<S;i++){
            p[i]=pi[i];
        }
    }

    data_array(unsigned int ri[S])
    {   HLS_FLATTEN_ARRAY(p);
        for (unsigned i=0;i<S;i++){
            p[i].r=ri[i];
        }
    }

    data_array(const data_array& oi)
    {
        for (unsigned i=0;i<S;i++){
            p[i]=oi.p[i];
        }
    }

    void set(DT pi[S])
    {
        for (unsigned i=0;i<S;i++){
            p[i]=pi[i];
        }
    }

    void set(const unsigned int ri[S])
    {
        for (unsigned i=0;i<S;i++){
            p[i].r=ri[i];
        }
    }

    void set(const data_array& px)
    {
        for (unsigned i=0;i<S;i++){
            p[i]=px.p[i];
        }
    }

    DT & operator [] (const unsigned i)
    {
        return p[i];
    }

    const DT & operator [] (const unsigned i) const
    {
        return p[i];
    }

    void operator = (const data_array& px)
    {
        set(px);
    }

    bool operator == (const data_array& px)
    {
        bool eq = true;
        for (unsigned i=0;i<S;i++){
            eq = eq && (p[i]== px.p[i]);
        }
        return eq;
    }

    bool operator != (const data_array& px)
    {
        return ! (*this == px);
    }
};

template < typename DT, unsigned S, unsigned DTBITS >
inline void cynw_interpret(const data_array<DT,S,DTBITS> &in, 
                           sc_uint<DTBITS*S> &out)
{
    for (unsigned i = 0; i < S; i++) {
        sc_uint<DTBITS> pix;
        cynw_interpret(in.p[i], pix);
        out.range((i+1)*DTBITS-1, i*DTBITS) = pix;
    }
}
template < typename DT, unsigned S, unsigned DTBITS >
inline void cynw_interpret(const sc_uint<DTBITS*S> &in, 
                           data_array<DT,S,DTBITS> &out)
{
    for (unsigned i = 0; i < S; i++) {
        sc_uint<DTBITS> pix;
        pix = in.range((i+1)*DTBITS-1, i*DTBITS);
        cynw_interpret(pix, out.p[i]);

    }
}

template < typename DT, unsigned S, unsigned DTBITS >
inline void cynw_interpret(const data_array<DT,S,DTBITS> &in, 
                           sc_biguint<DTBITS*S> &out)
{
    for (unsigned i = 0; i < S; i++) {
        sc_uint<DTBITS> pix;
        cynw_interpret(in.p[i], pix);
        out.range((i+1)*DTBITS-1, i*DTBITS) = pix;
    }
}
template < typename DT, unsigned S, unsigned DTBITS >
inline void cynw_interpret(const sc_biguint<DTBITS*S> &in, 
                           data_array<DT,S,DTBITS> &out)
{
    for (unsigned i = 0; i < S; i++) {
        sc_uint<DTBITS> pix;
        pix = in.range((i+1)*DTBITS-1, i*DTBITS);
        cynw_interpret(pix, out.p[i]);
        }
}
template < typename DT, unsigned S, unsigned DTBITS >
inline void sc_trace (sc_trace_file *tf, const data_array<DT,S,DTBITS> & px, const std::string& name)
{
    if(tf)
    {
        for (unsigned i = 0; i < S; i++) {
            char n[64];
            sprintf(n, ".p_%i", i);
            sc_trace(tf, px.p[i], name+std::string(n));
        }
    }
}
template < typename DT, unsigned S, unsigned DTBITS >
inline ostream & operator << (ostream& os, const data_array<DT,S,DTBITS> & px)
{
#ifndef STRATUS
    os << "(";
    for (unsigned i = 0; i < S; i++) {
        os << px.p[i] << " ";
    }
    os << ")";
#endif
    return os;
}

