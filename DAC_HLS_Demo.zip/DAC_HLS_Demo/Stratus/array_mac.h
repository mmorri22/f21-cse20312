///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

// Templated balanced-tree class to multiply and accumulate two arrays
// of equal size (not necessarily of the same type).

template< unsigned S, typename output_type, typename in1_type, typename in2_type = in1_type >
class array_mac
{
public:

    static output_type mac(const in1_type array1[S], const in2_type array2[S])
        {
            output_type outval = 0;

            const unsigned LH = (S/2);
            const unsigned UH = ((S % 2) == 0)? (LH) : (LH+1);

            in1_type a1_lh[LH];
            in1_type a1_uh[UH];

            in2_type a2_lh[LH];
            in2_type a2_uh[UH];
            
            output_type out_lh;
            output_type out_uh;

            for (unsigned i = 0; i < LH; i++)
            {
                a1_lh[i] = array1[i];
                a2_lh[i] = array2[i];
            }

            for (unsigned i = 0; i < UH; i++)
            {
                a1_uh[i] = array1[LH+i];
                a2_uh[i] = array2[LH+i];
            }

            out_lh = array_mac<LH, output_type, in1_type, in2_type>::mac(a1_lh, a2_lh);
            out_uh = array_mac<UH, output_type, in1_type, in2_type>::mac(a1_uh, a2_uh);

            outval = out_lh + out_uh;

            return outval;
        }
};

// specializations for arrays of size 1 and 2

template< typename output_type, typename in1_type, typename in2_type >
class array_mac< 1, output_type, in1_type, in2_type >
{
public:

    static output_type mac(const in1_type array1[1], const in2_type array2[1])
        {
            output_type outval = 0;

            outval = array1[0] * array2[0];

            return outval;
        }
};

// The size-2 specialization allows us to DpOpt the mult/add together.

template< typename output_type, typename in1_type, typename in2_type >
class array_mac< 2, output_type, in1_type, in2_type >
{
public:

    static output_type mac(const in1_type array1[2], const in2_type array2[2])
        {
            output_type outval = 0;

            { 
                HLS_DPOPT_REGION(0, "array_mac_2_dpo");
                // have to do two separate assignments due to saturated types.
                outval = array1[0] * array2[0];
                outval += array1[1] * array2[1];
            }

            return outval;
        }
};

