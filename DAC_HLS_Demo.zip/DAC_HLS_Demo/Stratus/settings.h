///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////
 
#pragma once

#include "systemc.h"
#include "stratus_hls.h"
#include "cynw_fixed.h"
#include "data_array.h"
#include "bias_struct.h"
#include "weight_struct.h"

// data path size in bits. This is the base number of bits used for
// all values in the neural network; extra bits are added by the later
// layers to improve accuracy.

static const unsigned DEF_BITS = 16;

class Conv1_settings
{
public:
  // constants
  static const unsigned SIZE_WS = 3;    // size of 2-D working set for 1 filter
  static const unsigned SIZE_RATIO = 1; // ratio of total image size to filter image size
  static const unsigned NUM_IN  = 1;    // number of parallel inputs
  static const unsigned NUM_OUT = 16;   // number of parallel outputs

  // types
  typedef sc_uint<10>                                  DT_SIZE; // data type for the image size input

  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_BIASVAL; // data type to be used for bias values
  typedef DT_BIASVAL                                   DT_WEIGHTVAL; // data type to be used for weight values

  typedef bias_struct< DT_BIASVAL, NUM_OUT >           DT_BIAS; // data type for the entire bias input struct

  // each output gets its own weight struct, passed in via
  // cynw_p2p. So NUM_OUT is 1 for the weight struct for each filter.

  typedef weight_struct< DT_WEIGHTVAL, 1, NUM_IN, SIZE_WS > DT_WEIGHT; // data type for the entire weight input struct

  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_INVAL; // data type of input values
  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_OUTVAL; // data type of output values

  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >    DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT > DT_OUTPUT; // data type of the entire output struct
  
};

class Pool1_settings
{
public:
  // constants
  static const unsigned SIZE_WS = 2;  // size of 2-D working set for pooling
  static const unsigned WS_STRIDE = SIZE_WS;  // stride of 2-D working set for pooling
  static const unsigned SIZE_RATIO = 1; // ratio of total image size to pooling image size
  static const unsigned NUM_IN  = 16; // number of parallel inputs
  static const unsigned NUM_OUT = NUM_IN; // number of parallel outputs

  // types
  typedef sc_uint<10>                                  DT_SIZE; // data type for the image size input

  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_INVAL; // data type of input values
  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_OUTVAL; // data type of output values
  
  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >    DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT > DT_OUTPUT; // data type of the entire output struct
  
};

class Conv2_settings
{
public:
  // constants
  static const unsigned SIZE_WS = 3;    // size of 2-D working set for 1 filter
  static const unsigned SIZE_RATIO = 2; // ratio of total image size to filter image size
  static const unsigned NUM_IN  = 16;   // number of parallel inputs
  static const unsigned NUM_OUT = 32;   // number of parallel outputs

  // types
  typedef sc_uint<10>                                  DT_SIZE; // data type for the image size input

  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_BIASVAL; // data type to be used for bias values
  typedef DT_BIASVAL                                   DT_WEIGHTVAL; // data type to be used for weight values

  typedef bias_struct< DT_BIASVAL, NUM_OUT >           DT_BIAS; // data type for the entire bias input struct

  // each output gets its own weight struct, passed in via
  // cynw_p2p. So NUM_OUT is 1 for the weight struct for each filter.

  typedef weight_struct< DT_WEIGHTVAL, 1, NUM_IN, SIZE_WS > DT_WEIGHT; // data type for the entire weight input struct

  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>      DT_INVAL; // data type of input values
  typedef cynw_fixed<(DEF_BITS+8), 8, SC_TRN, SC_SAT>      DT_OUTVAL; // data type of output values
  
  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >    DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT > DT_OUTPUT; // data type of the entire output struct
  
};

class Pool2_settings
{
public:
  // constants
  static const unsigned SIZE_WS = 2;  // size of 2-D working set for pooling
  static const unsigned WS_STRIDE = SIZE_WS;  // stride of 2-D working set for pooling
  static const unsigned SIZE_RATIO = 2; // ratio of total image size to pooling image size
  static const unsigned NUM_IN  = 32;  // number of parallel inputs
  static const unsigned NUM_OUT = NUM_IN; // number of parallel outputs

  // types
  typedef sc_uint<10>                                  DT_SIZE; // data type for the image size input

  typedef cynw_fixed<(DEF_BITS+8), 8, SC_TRN, SC_SAT>      DT_INVAL; // data type of input values
  typedef cynw_fixed<(DEF_BITS+8), 8, SC_TRN, SC_SAT> DT_OUTVAL; // data type of output values
  
  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >    DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT > DT_OUTPUT; // data type of the entire input struct
  
};

class FCL_settings
{
  
public:
  // constants
  static const unsigned IN_ROWS = 1;     // number of rows in input matrix
  static const unsigned IN_COLS = 7*7*32; // number of colums in input matrix
  static const unsigned OUT_COLS = 1024; // number of colums in output matrix

  static const unsigned NUM_IN  = 32;   // number of parallel inputs
  static const unsigned NUM_OUT = 32;   // number of parallel outputs

  static const bool DO_RELU = true;

  // types
  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>       DT_BIASVAL; // data type to be used for bias values
  typedef DT_BIASVAL                                    DT_WEIGHTVAL; // data type to be used for weight values

  typedef bias_struct< DT_BIASVAL, NUM_OUT >            DT_BIAS; // data type for the entire bias input struct

  // The "working set" size for the FCL weights is 1x1, since this
  // block is not a convolutiono filter.

  typedef weight_struct< DT_WEIGHTVAL, NUM_OUT, NUM_IN, 1 > DT_WEIGHT; // data type for the entire weight input struct

  typedef cynw_fixed<(DEF_BITS+8), 8, SC_TRN, SC_SAT>  DT_INVAL; // data type of input values
  typedef cynw_fixed<(DEF_BITS+16), 24, SC_TRN, SC_SAT> DT_OUTVAL; // data type of output values
  
  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >     DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT >  DT_OUTPUT; // data type of the entire input struct
  
};

class OL_settings
{
  
public:
  // constants
  static const unsigned IN_ROWS = 1;     // number of rows in input matrix
  static const unsigned IN_COLS = 1024; // number of colums in input matrix
  static const unsigned OUT_COLS = 10; // number of colums in output matrix

  static const unsigned NUM_IN  = 32;   // number of parallel inputs
  static const unsigned NUM_OUT = 10;   // number of parallel outputs

  static const bool DO_RELU = false;

  // types
  typedef cynw_fixed<DEF_BITS, 5, SC_TRN, SC_SAT>       DT_BIASVAL; // data type to be used for bias values
  typedef DT_BIASVAL                                    DT_WEIGHTVAL; // data type to be used for weight values

  typedef bias_struct< DT_BIASVAL, NUM_OUT >            DT_BIAS; // data type for the entire bias input struct

  // The "working set" size for the OL weights is 1x1, since this
  // block is not a convolutiono filter.

  typedef weight_struct< DT_WEIGHTVAL, NUM_OUT, NUM_IN, 1 > DT_WEIGHT; // data type for the entire weight input struct

  typedef cynw_fixed<(DEF_BITS+16), 24, SC_TRN, SC_SAT> DT_INVAL; // data type of input values
  typedef cynw_fixed<(DEF_BITS+16), 24, SC_TRN, SC_SAT> DT_OUTVAL; // data type of output values
  
  static const unsigned BITS_DT_IN = DT_INVAL::TP_W;
  static const unsigned BITS_DT_OUT = DT_OUTVAL::TP_W;

  typedef data_array<DT_INVAL, NUM_IN, BITS_DT_IN >     DT_INPUT; // data type of the entire input struct
  typedef data_array<DT_OUTVAL, NUM_OUT, BITS_DT_OUT >  DT_OUTPUT; // data type of the entire input struct
  
};

// Include the line buffers for the image storage. These must be
// included after the settings classes are defined since the line
// buffers use the types from the settings. In addition, there must be
// a global typedef with the correct name as expected by the line
// buffers.

typedef Conv1_settings::DT_INPUT  Conv1_DT_INPUT;
typedef Conv2_settings::DT_INPUT  Conv2_DT_INPUT;
typedef Pool1_settings::DT_INPUT  Pool1_DT_INPUT;
typedef Pool2_settings::DT_INPUT  Pool2_DT_INPUT;

#include "lb_in_Conv1.h"
#include "lb_in_Conv2.h"
#include "lb_in_Pool1.h"
#include "lb_in_Pool2.h"
