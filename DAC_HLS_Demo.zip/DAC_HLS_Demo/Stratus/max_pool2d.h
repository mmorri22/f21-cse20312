///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "settings.h"

#include "cynw_p2p.h"
#include "cynw_utilities.h"

template <typename SETTINGS, typename LINEBUFFER_PORT >
class max_pool2d : public sc_module
{
public:

    // typedefs/constants from settings class
    typedef typename SETTINGS::DT_SIZE   size_type;

    typedef typename SETTINGS::DT_INVAL  inval_type;
    typedef typename SETTINGS::DT_OUTVAL outval_type;

    typedef typename SETTINGS::DT_INPUT  input_type;
    typedef typename SETTINGS::DT_OUTPUT output_type;

    static const unsigned SIZE_WS = SETTINGS::SIZE_WS;
    static const unsigned WS_STRIDE = SETTINGS::WS_STRIDE;
    static const unsigned SIZE_WS_SQ = (SIZE_WS*SIZE_WS);
    static const unsigned SIZE_RATIO = SETTINGS::SIZE_RATIO;
    static const unsigned NUM_IN = SETTINGS::NUM_IN;
    static const unsigned NUM_OUT = SETTINGS::NUM_OUT;

    SC_HAS_PROCESS(max_pool2d);

    // reset and clock are required ports
    sc_in < bool >  rst;
    sc_in_clk        clk;

    // stable inputs for image sizes
    sc_in < size_type > x_size;
    sc_in < size_type > y_size;

    // line buffer input, cynw_p2p output
    typedef LINEBUFFER_PORT                                  in_port_type;
    typedef typename cynw_p2p < output_type, ioConfig >::out out_port_type;

    in_port_type in;
    out_port_type out;

    // constructor
    max_pool2d( sc_module_name name =
                sc_module_name( sc_gen_unique_name("max_pool2d") ) )
        : sc_module(name)
        , rst("rst")
        , clk("clk")
        , x_size("x_size")
        , y_size("y_size")
        , in("in")
        , out("out")
        {

            SC_CTHREAD(max_pool2d_thread, clk.pos());
            reset_signal_is(rst, false);

            in.clk_rst(clk, rst);
            out.clk_rst(clk, rst);

        }

    // main thread
    void max_pool2d_thread()
        {
            // size checks
            assert((NUM_IN == NUM_OUT));

            // reset the interfaces
            {
                HLS_DEFINE_PROTOCOL("reset");
                out.reset();
                in.reset();
                wait();
            }

            while (true)
            {
                HLS_ASSUME_STABLE(x_size);
                HLS_ASSUME_STABLE(y_size);

                input_type workingSet[SIZE_WS][SIZE_WS];

                in.set_size(y_size.read()/(SIZE_RATIO), x_size.read()/(SIZE_RATIO));

                in.start_tx();
                while (!in.y_done())
                {
                    while (!in.x_done())
                    {
                        output_type newOutput;
                        //
                        //  Read the input data
                        //
                        // The WS_STRIDE setting is used to skip
                        // overlapping working sets. in.x() and in.y()
                        // return the current X/Y position of the
                        // working set in the image.
                        in.get(workingSet);
                        if ((in.x() % (WS_STRIDE) == 0)
                            && (in.y() % (WS_STRIDE) == 0))
                        {
                            //
                            //  do the max_pooling.
                            //
                            newOutput = max_pooling(workingSet);
                            //
                            //  Output data
                            //
                            out.put(newOutput);
                        }

                    }
                    in.next_y();
                }
                in.end_tx();
            }
        }

    // the max pooling function
    const output_type max_pooling(const input_type workingSet[SIZE_WS][SIZE_WS])
        {
            output_type result;

            // The number of parallel inputs is always the same as
            // number of parallel outputs.
            for (unsigned ip = 0; ip < NUM_IN; ip++)
            {
                HLS_DPOPT_REGION(0,"max_pool2d_dpo");

                outval_type arr_p[SIZE_WS_SQ];
                // collect the values into a 1-D array so we can use
                // the cynw::max utility function.
                for (unsigned i = 0; i < SIZE_WS; i++)
                {
                    for (unsigned j = 0; j < SIZE_WS; j++)
                    {
                        arr_p[i*(SIZE_WS)+j] = workingSet[i][j][ip];
                    }
                }
                result[ip] = cynw::max<SIZE_WS_SQ>(arr_p);
            }

            return result;
        }

};

