///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "settings.h"

#include "cynw_p2p.h"

#include "tb.h"

// Line buffers
#include "lb_in_Conv1.h"
#include "lb_in_Pool1.h"
#include "lb_in_Conv2.h"
#include "lb_in_Pool2.h"

// Stratus generated wrappers for each HLS module
#include "Conv1_wrap.h"
#include "Pool1_wrap.h"
#include "Conv2_wrap.h"
#include "Pool2_wrap.h"
#include "FCL_wrap.h"
#include "OL_wrap.h"


SC_MODULE(top)
{
public:

    // typedefs/constants from settings classes
    typedef typename Conv1_settings::DT_SIZE   size_type;

    sc_clock clk;
    sc_signal<bool> rst;

    // stable inputs for image sizes
    sc_signal < size_type > x_size;
    sc_signal < size_type > y_size;

    // The weight and bias values are not stable inputs, but use p2p
    // since they are sent in chunks.

    cynw_p2p < Conv1_settings::DT_WEIGHT, ioConfig >::chan w_Conv1;
    cynw_p2p < Conv2_settings::DT_WEIGHT, ioConfig >::chan w_Conv2;
    cynw_p2p < FCL_settings::DT_WEIGHT, ioConfig >::chan   w_FCL;
    cynw_p2p < OL_settings::DT_WEIGHT, ioConfig >::chan    w_OL;

    cynw_p2p < Conv1_settings::DT_BIAS, ioConfig >::chan   b_Conv1;
    cynw_p2p < Conv2_settings::DT_BIAS, ioConfig >::chan   b_Conv2;
    cynw_p2p < FCL_settings::DT_BIAS, ioConfig >::chan     b_FCL;
    cynw_p2p < OL_settings::DT_BIAS, ioConfig >::chan      b_OL;

    // line buffers
    lb_in_Conv1::chan<ioConfig > lb_Conv1; // between TB and Conv1, holds image input values
    lb_in_Pool1::chan<ioConfig > lb_Pool1; // between Conv1 and Pool1, holds conv1_out values
    lb_in_Conv2::chan<ioConfig > lb_Conv2; // between Pool1 and Conv2, holds pool1_out values
    lb_in_Pool2::chan<ioConfig > lb_Pool2; // betweek Conv2 and Pool2, holds conv2_out values

    // p2p output channels
    cynw_p2p< Pool2_settings::DT_OUTPUT, ioConfig >::chan  Pool2_out;
    cynw_p2p< FCL_settings::DT_OUTPUT, ioConfig >::chan    FCL_out;
    cynw_p2p< OL_settings::DT_OUTPUT, ioConfig >::chan     OL_out;

    // submodules
    tb            iTb;
    Conv1_wrapper iConv1;
    Pool1_wrapper iPool1;
    Conv2_wrapper iConv2;
    Pool2_wrapper iPool2;
    FCL_wrapper   iFCL;
    OL_wrapper    iOL;

    // constructor
    SC_CTOR(top)
        : clk("clk", CLOCK_PERIOD, CLOCK_UNITS) // CLOCK_PERIOD defined as a macro in project.tcl
        , rst("rst")
        , x_size("x_size")
        , y_size("y_size")
        , w_Conv1("w_Conv1")
        , w_Conv2("w_Conv2")
        , w_FCL("w_FCL")
        , w_OL("w_OL")
        , b_Conv1("b_Conv1")
        , b_Conv2("b_Conv2")
        , b_FCL("b_FCL")
        , b_OL("b_OL")
        , lb_Conv1("lb_Conv1")
        , lb_Pool1("lb_Pool1")
        , lb_Conv2("lb_Conv2")
        , lb_Pool2("lb_Pool2")
        , Pool2_out("Pool2_out")
        , FCL_out("FCL_out")
        , OL_out("OL_out")
        , iTb("iTb")
        , iConv1("iConv1")
        , iPool1("iPool1")
        , iConv2("iConv2")
        , iPool2("iPool2")
        , iFCL("iFCL")
        , iOL("iOL")
    {
        // Module interconnect
        iTb.clk(clk);
        iTb.rst(rst);
        iTb.x_size(x_size);
        iTb.y_size(y_size);
        iTb.w_Conv1(w_Conv1);
        iTb.w_Conv2(w_Conv2);
        iTb.b_FCL(b_FCL);
        iTb.w_FCL(w_FCL);
        iTb.b_Conv1(b_Conv1);
        iTb.b_Conv2(b_Conv2);
        iTb.b_OL(b_OL);
        iTb.w_OL(w_OL);

        iTb.out(lb_Conv1); // start of main image datapath, testbench output

        iConv1.clk(clk);
        iConv1.rst(rst);
        iConv1.x_size(x_size);
        iConv1.y_size(y_size);
        iConv1.w(w_Conv1);
        iConv1.b(b_Conv1);
        iConv1.in(lb_Conv1);
        iConv1.out(lb_Pool1);

        iPool1.clk(clk);
        iPool1.rst(rst);
        iPool1.x_size(x_size);
        iPool1.y_size(y_size);
        iPool1.in(lb_Pool1);
        iPool1.out(lb_Conv2);

        iConv2.clk(clk);
        iConv2.rst(rst);
        iConv2.x_size(x_size);
        iConv2.y_size(y_size);
        iConv2.w(w_Conv2);
        iConv2.b(b_Conv2);
        iConv2.in(lb_Conv2);
        iConv2.out(lb_Pool2);

        iPool2.clk(clk);
        iPool2.rst(rst);
        iPool2.x_size(x_size);
        iPool2.y_size(y_size);
        iPool2.in(lb_Pool2);
        iPool2.out(Pool2_out);

        iFCL.clk(clk);
        iFCL.rst(rst);
        iFCL.w(w_FCL);
        iFCL.b(b_FCL);
        iFCL.in(Pool2_out);
        iFCL.out(FCL_out);

        iOL.clk(clk);
        iOL.rst(rst);
        iOL.w(w_OL);
        iOL.b(b_OL);
        iOL.in(FCL_out);
        iOL.out(OL_out);

        iTb.in(OL_out);  // final layer output, testbench input
    }

};

