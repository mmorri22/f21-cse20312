///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#include <systemc.h>

//Header for esc functions
#include "esc.h"

// Wall Clock Time Measurement
#include <sys/time.h>
#include <string>

// Top-level module (Design+Testbench) Header
#include "top.h"

using namespace std;

// TIMEVAL STRUCT IS Defined ctime
// use start_time and end_time variables to capture 
// start of simulation and end of simulation
struct timeval start_time, end_time;


top * iTop = NULL;

extern void esc_elaborate()
{
    cout << "Entering Elaboration" << endl;
    iTop = new top("Top");
    cout << "Completing Elaboration" << endl;
}
extern void esc_cleanup()
{
    cout << "Entering Cleanup" << endl;
    delete iTop;
    cout << "Completing Cleanup" << endl;
}
int sc_main(int argc, char *argv[])
{

    gettimeofday(&start_time, 0);

    esc_initialize(argc, argv);
    esc_elaborate();
    cout << "Starting Simulation" << endl;

    sc_start();

    gettimeofday(&end_time, 0);
    int total_usecs = (end_time.tv_sec - start_time.tv_sec) * 1000000 +
                     (end_time.tv_usec - start_time.tv_usec);

    cout << "==============================================="<< endl;
    cout << "   Time Taken for simulation is: " << total_usecs << " uS" << endl;
    cout << "==============================================="<< endl;

    return 0;
}

