///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include <fstream>

#include "tb.h"
#include "cynw_utilities.h"

void tb::read_files()
{
    // Read and fill in the bias and weight structures.

    cout << "TB: Reading weights and bias" << endl;

    std::ifstream file;
    std::string str, filename;
    double val;
    unsigned i, j, k, l, row, col, index;

    const unsigned FCL_IN_CHUNKS = FCL_settings::IN_COLS/FCL_settings::NUM_IN;
    const unsigned FCL_OUT_CHUNKS = FCL_settings::OUT_COLS/FCL_settings::NUM_OUT;

    const unsigned OL_IN_CHUNKS = OL_settings::IN_COLS/OL_settings::NUM_IN;
    const unsigned OL_OUT_CHUNKS = OL_settings::OUT_COLS/OL_settings::NUM_OUT;

    // Load weights and biases

    // Conv1 weights. One set of weights is read in for each output channel.
    filename = weights_dir + "/w_Conv1.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      for (i=0; i<Conv1_settings::NUM_OUT; i++){
        Conv1_settings::DT_WEIGHT w_Conv1_tmp;
        file >> w_Conv1_tmp;
        // cout << "w_Conv1[o=" << i << "] = " << w_Conv1 << endl << endl;
        w_Conv1_vec.push_back(w_Conv1_tmp);
      }
      file.close();
    }

    // Conv2 weights. One set of weights is read in for each output channel.
    filename = weights_dir + "/w_Conv2.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      for (i=0; i<Conv2_settings::NUM_OUT; i++){
        Conv2_settings::DT_WEIGHT w_Conv2_tmp;
        file >> w_Conv2_tmp;
        // cout << "w_Conv2[o=" << i << "] = " << w_Conv2 << endl << endl;
        w_Conv2_vec.push_back(w_Conv2_tmp);
      }
      file.close();
    }

    // FCL weights

    // one weight_struct contains a 2-D array of NUM_IN*NUM_OUT values.
    filename = weights_dir + "/w_FCL.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      while (!file.eof())
        {
          FCL_settings::DT_WEIGHT w_FCL_tmp;
          file >> w_FCL_tmp;
          // cout << "w_FCL[index=" << w_FCL_vec.size() << "] = " << w_FCL << endl << endl;
          w_FCL_vec.push_back(w_FCL_tmp);
        }
      if (w_FCL_vec.size() != (FCL_OUT_CHUNKS*FCL_IN_CHUNKS))
        {
          // incomplete set read from file
          cout << "Warning: partial FCL weight vector in file "
               << filename << ", got " << (w_FCL_vec.size()*FCL_settings::NUM_OUT*FCL_settings::NUM_IN)
               << " value(s), expected "
               << (FCL_settings::IN_COLS) * (FCL_settings::OUT_COLS)
               << endl;
        }
      file.close();
    }

    // OL weights

    // one weight_struct contains a 2-D array of NUM_IN*NUM_OUT values.
    filename = weights_dir + "/w_OL.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      while (!file.eof())
        {
          OL_settings::DT_WEIGHT w_OL_tmp;
          file >> w_OL_tmp;
          // cout << "w_OL[index=" << w_OL_vec.size() << "] = " << w_OL << endl << endl;
          w_OL_vec.push_back(w_OL_tmp);
        }
      if (w_OL_vec.size() != (OL_OUT_CHUNKS*OL_IN_CHUNKS))
        {
          // incomplete set read from file
          cout << "Warning: partial OL weight vector in file "
               << filename << ", got " << (w_OL_vec.size()*OL_settings::NUM_OUT*OL_settings::NUM_IN)
               << " value(s), expected "
               << (OL_settings::IN_COLS) * (OL_settings::OUT_COLS)
               << endl;
        }
      file.close();
    }


    // Conv1 bias
    filename = weights_dir + "/b_Conv1.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      while (!file.eof())
        {
          Conv1_settings::DT_BIAS b_Conv1_tmp;
          file >> b_Conv1_tmp;
          b_Conv1_vec.push_back(b_Conv1_tmp);
        }
      file.close();
    }

    // Conv2 bias
    filename = weights_dir + "/b_Conv2.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      while (!file.eof())
        {
          Conv2_settings::DT_BIAS b_Conv2_tmp;
          file >> b_Conv2_tmp;
          b_Conv2_vec.push_back(b_Conv2_tmp);
        }
      file.close();
    }

    // FCL bias
    filename = weights_dir + "/b_FCL.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      for (i=0; i<(FCL_OUT_CHUNKS) && !(file.eof()); i++){
        FCL_settings::DT_BIAS b_FCL_tmp;
        file >> b_FCL_tmp;
        b_FCL_vec.push_back(b_FCL_tmp);
      }
      file.close();
    }

    // OL bias
    filename = weights_dir + "/b_OL.txt";
    file.open(filename.c_str());
    if (!file.is_open()) {
        cout << "ERROR: Cound not open weights file: " << filename << endl;
    } else {
      for (i=0; i<(OL_OUT_CHUNKS) && !(file.eof()); i++){
        OL_settings::DT_BIAS b_OL_tmp;
        file >> b_OL_tmp;
        b_OL_vec.push_back(b_OL_tmp);
      }
      file.close();
    }

    cout << "TB: Done reading weights and bias" << endl;
}


void tb::input_Conv1()     //Data Source Thread
{
    // Default test is for 10 input files.

    num_images = 10;

    if (esc_argc() > 1)
    {
        // The argument at index 1 is the number of images to run.
        num_images = atoi(esc_argv(1));
    }
    cout << "Running " << num_images << " images through the design." << endl;
    for (unsigned inp_i=0; inp_i<num_images; inp_i++)
    {

        //Declare and define internal variables
        unsigned long in_row_count=0;
        unsigned long in_pix_indx=0;
        // Load inputs
        // read txt files
        vector < Conv1_settings::DT_INVAL > tmp_buff[Conv1_settings::NUM_IN]; // one vector for each input slice
        ifstream file[Conv1_settings::NUM_IN];
        ostringstream oss;
        string filename;
        bool fail = false;
        for (unsigned i=0; i<Conv1_settings::NUM_IN; i++){
            oss << test_dir << "/" << inp_i << ".txt";
            filename = oss.str();
            cout << "current input: " << filename << endl;
            file[i].open(filename.c_str());
            if (!file[i].is_open())
            {
                cout << "ERROR: Cound not open input file: " << filename << endl;
                fail = true;
            }
        }

        if (fail)
        {
            break;
        }

        double val;
        while (!file[0].eof()) { // assume all slices have the same amount of data
            for (unsigned j=0; j<Conv1_settings::NUM_IN; j++){
                if (!file[j].eof()) {
                    file[j] >> val;
                    if (!file[j].fail()) {
                        tmp_buff[j].push_back(val);
                    }
                    file[j] >> ws;
                }
            }
        }

        cout << "Input data size is " << tmp_buff[0].size() << endl;

        for (unsigned i=0; i<Conv1_settings::NUM_IN; i++){
            file[i].close();
        }

        // The assumption here is that the tmp_buff vectors contain
        // pixel data for a -square- image. The x/y values should be
        // actual image sizes, and they need not be square images.
        size_type xsize = size_type(sqrt(tmp_buff[0].size()));
        size_type ysize = xsize;

        // reset
        rst.write(0);
        out.reset();
        done.reset_in();

        // write stable inputs
        x_size.write(xsize);
        y_size.write(ysize);
        wait(5);
        rst = 1;

        Conv1_settings::DT_INPUT p_tmp;;
        bool start = true;
        out.set_size(ysize, xsize);
        out.start_tx();

        unsigned int in_p_count = 0;
        unsigned int in_pix_count = 0;

        while (!out.y_done())
        {

            while(!out.x_done())
            {

                in_pix_indx = in_pix_count;

                for (unsigned i=0;i<Conv1_settings::NUM_IN;i++){
                    p_tmp[i] = tmp_buff[i][in_pix_indx];
                }

                out.put(p_tmp);
                if (start) {
                    start_time = sc_time_stamp();
                    start = false;
                }

                in_p_count = in_pix_count;
                in_pix_count++;
            }
            out.next_y();

            in_row_count++;
        }
        out.end_tx();
        cout << sc_time_stamp() << ": TB: Done sending inputs, waiting for results." << endl << flush;

        done.get(); // Use p2p handshake for getting a signal from output thread

        cout << sc_time_stamp() << ": TB: Done with input file " << filename << endl << flush;
    }
    // all done.
    esc_stop();
}

void tb::input_w_Conv1()
{
    // send Conv1 weights over p2p.

    w_Conv1.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < w_Conv1_vec.size(); i++)
        {
            w_Conv1.put(w_Conv1_vec[i]);
        }
    }
}

void tb::input_w_Conv2()
{
    // send Conv2 weights over p2p.

    w_Conv2.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < w_Conv2_vec.size(); i++)
        {
            w_Conv2.put(w_Conv2_vec[i]);
        }
    }
}


void tb::input_w_FCL()
{
    // send FCL weights over p2p.
    w_FCL.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < w_FCL_vec.size(); i++)
        {
            w_FCL.put(w_FCL_vec[i]);
        }
    }
}


void tb::input_w_OL()
{
    // send OL weights over p2p.
    w_OL.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < w_OL_vec.size(); i++)
        {
            w_OL.put(w_OL_vec[i]);
        }
    }
}

void tb::input_b_Conv1()
{
    // send Conv1 biases over p2p.

    b_Conv1.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < b_Conv1_vec.size(); i++)
        {
            b_Conv1.put(b_Conv1_vec[i]);
        }
    }
}

void tb::input_b_Conv2()
{
    // send Conv2 biases over p2p.

    b_Conv2.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < b_Conv2_vec.size(); i++)
        {
            b_Conv2.put(b_Conv2_vec[i]);
        }
    }
}

void tb::input_b_FCL()
{
    // send FCL biases over p2p.
    b_FCL.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < b_FCL_vec.size(); i++)
        {
            b_FCL.put(b_FCL_vec[i]);
        }
    }
}

void tb::input_b_OL()
{
    // send OL biases over p2p.
    b_OL.reset();
    wait();

    while (true)
    {
        for (unsigned i = 0; i < b_OL_vec.size(); i++)
        {
            b_OL.put(b_OL_vec[i]);
        }
    }
}

void tb::output_OL()       //Data Sink Thread
{
    // This thread is sensitive to reset and re-starts for every input image in the test suite.
    // reset
    done.reset_out();

    in.reset();
    wait();

    // The assumption is that the xsize/ysize values are set by the
    // data source thread (input_Conv1 above) before reset is
    // deactivated. So we can read the x_size/y_size signals to get
    // the image size.

    bool first_count = true;
    unsigned long out_pix_count=0;
    unsigned long out_pix_indx=0;
    unsigned long out_row_count=0;

    size_type xsize = x_size.read();
    size_type ysize = y_size.read();

    cout << "width:" << xsize << endl ;
    cout << "height:" << ysize << endl ;

    // Save outputs to txt files
    ofstream outfstr[OL_settings::NUM_OUT];
    string filename;
    for (unsigned i=0;i<OL_settings::NUM_OUT;i++){
        stringstream out;
        out << output_dir << "/out_" << i << ".txt";
        outfstr[i].open(out.str().c_str(), first? std::ios_base::out : std::ios_base::app);
    }
    std::ofstream outfile;
    filename = output_dir + "/results.txt";
    outfile.open(filename.c_str(), first? std::ios_base::out : std::ios_base::app);
    first = false;


    // latency measurement.
    sc_clock * clk_p = DCAST<sc_clock *>( clk.get_interface() );
    sc_time clock_period = clk_p->period(); /* get period from the sc_clock object. */

    while(true)
    {
        const unsigned OL_OUT_CHUNKS = OL_settings::OUT_COLS/OL_settings::NUM_OUT;

        data_array<OL_settings::DT_OUTVAL, OL_settings::OUT_COLS, OL_settings::BITS_DT_OUT > output;

        for (unsigned oc = 0; oc < OL_OUT_CHUNKS; oc++)
        {
            // get one chunk of output, place in local array.
            OL_settings::DT_OUTPUT dout = in.get();
            for (unsigned i = 0; i < OL_settings::NUM_OUT; i++) {
                output[oc*OL_OUT_CHUNKS + i] = dout[i];
            }
        }

        // Classification - Pick the maximum index
        unsigned max_index = cynw::max_index<OL_settings::OUT_COLS>(output.p);
        cout << "Prediction result: " << max_index << endl;
        results_vec.push_back(max_index);

        outfile << max_index << endl;

        sc_time end_time = sc_time_stamp();
        double latency = ( end_time - start_time ) / clock_period;

        cout << "The Latency for the output is " << latency << " cycles" << endl;
        cout << "--------------------------------------------- " << endl << endl;

        for (unsigned i=0;i<OL_settings::OUT_COLS;i++)
        {
            outfstr[i] << output[i] << endl ;
        }

        done.put();

        //
    } // while loop
}

// timeout thread.
void tb::timer()
{
    const unsigned max_cycles = 30000000; // 2.3e+6 for each image in the slow config
    wait(max_cycles);
    cout << endl << sc_time_stamp() << ": TB: TIMED OUT: Stopping simualtion, check for errors." << endl << endl;
    timed_out = true;
    esc_stop();
}

void tb::check_results()
{
    // This function is called -after- sc_stop has been called (via
    // end_of_simulation), so either all expected outputs were
    // received, or the simulation timed out via the timer thread (the
    // latter sets a flag).

    bool error = timed_out;
    unsigned num_results = results_vec.size();

    if (num_images != num_results)
    {
        cout << "ERROR: Partial results: expected " << num_images << ", received " << num_results << endl;
        error = true;
    }

    std::ifstream golden;
    std::string s;
    s = test_dir + "/labels.txt";
    golden.open(s.c_str());

    if (golden.fail())
    {
        cout << "ERROR: Could not open golden results file " << s << endl;
        error = true;
    } 

    unsigned num_checks = 0;
    unsigned num_diffs = 0;

    while (!golden.eof() && (num_checks < num_results))
    {
        unsigned g;
        golden >> g;
        if (!golden.fail())
        {
            if (g != results_vec[num_checks])
            {
                ++num_diffs;
            }
        }
        else
        {
            break;
        }
        golden >> ws;
        ++num_checks;
    }

    if (num_checks != num_results)
    {
        cout << "ERROR: Golden results file does not have enough data: expected " << num_results << ", contains only " << num_checks << " values." << endl;
        error = true;
    }

    // Note: an accuracy of < 100% is still a simulation PASS.

    double accuracy = 100.0 - ((double(num_diffs)/double(num_checks))*100.0);

    cout << "****************************************" << endl;
    cout << "Results summary for " << getenv("BDW_SIM_CONFIG") << " simulation:" << endl;
    cout << endl;
    cout << "Total number of results received: " << num_results << endl;
    cout << "Results different from golden:    " << num_diffs << endl;
    cout << endl;
    cout << "Accuracy: " << accuracy << "%." << endl;
    cout << endl;
    cout << "****************************************" << endl;

    if (error)
    {
        esc_log_fail();
        cout << "****************************************" << endl;
        cout << "SIMULATION FAILED, CHECK FOR ERRORS." << endl;
        cout << "****************************************" << endl;
    }
    else
    {
        esc_log_pass();
        cout << "****************************************" << endl;
        cout << "SIMULATION PASSED." << endl;
        cout << "****************************************" << endl;
    }
}
