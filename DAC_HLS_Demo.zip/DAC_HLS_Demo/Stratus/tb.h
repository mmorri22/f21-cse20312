///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include <string>
#include <systemc.h>

#include "settings.h"

#include "cynw_p2p.h"
#include "lb_in_Conv1.h"

using namespace std;

class tb : public sc_module
{
    // typedefs/constants from settings classes
    typedef typename Conv1_settings::DT_SIZE   size_type;

public:
    SC_HAS_PROCESS(tb);

    // reset and clock are required ports
    sc_out<bool>     rst;
    sc_in_clk        clk;

    // stable inputs for image sizes
    sc_out < size_type > x_size;
    sc_out < size_type > y_size;

    // The weights and biases use p2p since they are sent in chunks.

    cynw_p2p < Conv1_settings::DT_WEIGHT, ioConfig >::out w_Conv1;
    cynw_p2p < Conv2_settings::DT_WEIGHT, ioConfig >::out w_Conv2;
    cynw_p2p < FCL_settings::DT_WEIGHT, ioConfig >::out   w_FCL;
    cynw_p2p < OL_settings::DT_WEIGHT, ioConfig >::out    w_OL;

    cynw_p2p < Conv1_settings::DT_BIAS, ioConfig >::out   b_Conv1;
    cynw_p2p < Conv2_settings::DT_BIAS, ioConfig >::out   b_Conv2;
    cynw_p2p < FCL_settings::DT_BIAS, ioConfig >::out     b_FCL;
    cynw_p2p < OL_settings::DT_BIAS, ioConfig >::out      b_OL;

    // data sent into Conv1
    lb_in_Conv1::out < ioConfig >                         out;

    // data received from ol
    cynw_p2p< OL_settings::DT_OUTPUT, ioConfig >::in      in;

    cynw_p2p_direct <cynw_void> done;

    tb( const sc_module_name &name = sc_gen_unique_name("tb") )
        : sc_module(name)
        , clk("clk")
        , rst("rst")
        , x_size("x_size")
        , y_size("y_size")
        , w_Conv1("w_Conv1")
        , w_Conv2("w_Conv2")
        , w_FCL("w_FCL")
        , w_OL("w_OL")
        , b_Conv1("b_Conv1")
        , b_Conv2("b_Conv2")
        , b_FCL("b_FCL")
        , b_OL("b_OL")
        , out("out")
        , in("in")
        , done("done")
        , first(true)
        , timed_out(false)
        , num_images(0)
        {
            // Read the weights and biases

            model_dir = "../Model";
            weights_dir = model_dir + "/Weights";
            test_dir = model_dir + "/Tests";
            output_dir = getenv("BDW_SIM_CONFIG_DIR")? getenv("BDW_SIM_CONFIG_DIR") : "./Outputs";

            read_files();

            // The TB needs separate threads for writing the data
            // input into CONV1, the four separate weight inputs, and the
            // biases for the FCL and the OL. The CONV1 and CONV2 bias
            // inputs are stable and driven by the CONV1/CONV2 weight
            // thread.

            SC_CTHREAD(input_Conv1, clk.pos()); // this thread generates the reset
            set_stack_size(0x10000000);

            SC_CTHREAD(input_w_Conv1, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_w_Conv2, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_w_FCL, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_w_OL, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_b_Conv1, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_b_Conv2, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_b_FCL, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(input_b_OL, clk.pos());
            reset_signal_is(rst, false);
            set_stack_size(0x10000000);

            SC_CTHREAD(output_OL, clk.pos());
            reset_signal_is(rst, false);

            SC_CTHREAD(timer, clk.pos());

            w_Conv1.clk_rst(clk, rst);
            w_Conv2.clk_rst(clk, rst);
            w_FCL.clk_rst(clk, rst);
            w_OL.clk_rst(clk, rst);
            b_Conv1.clk_rst(clk, rst);
            b_Conv2.clk_rst(clk, rst);
            b_FCL.clk_rst(clk, rst);
            b_OL.clk_rst(clk, rst);
            out.clk_rst(clk, rst);
            in.clk_rst(clk, rst);

            done.clk_rst(clk, rst);

        }//SC_CTOR(tb)

    ~tb()  //Destructor
        {
        } //End of Destructor


    // end-of-simulation callback

    virtual void end_of_simulation()
        {
            check_results();
        }

    // Member functions
    void read_files();

    void input_Conv1();
    void input_w_Conv1();
    void input_w_Conv2();
    void input_w_FCL();
    void input_w_OL();
    void input_b_Conv1();
    void input_b_Conv2();
    void input_b_FCL();
    void input_b_OL();
    void output_OL();
    void timer();

    void check_results();

    // class variables. These are initialized by the read_files
    // function.

    // Weight and bias vectors.

    vector< Conv1_settings::DT_WEIGHT > w_Conv1_vec;
    vector< Conv2_settings::DT_WEIGHT > w_Conv2_vec;
    vector< FCL_settings::DT_WEIGHT >   w_FCL_vec;
    vector< OL_settings::DT_WEIGHT >    w_OL_vec;

    vector<Conv1_settings::DT_BIAS >    b_Conv1_vec;
    vector<Conv2_settings::DT_BIAS >    b_Conv2_vec;
    vector<FCL_settings::DT_BIAS >      b_FCL_vec;
    vector<OL_settings::DT_BIAS >       b_OL_vec;

    // results received by the TB output sink thread.
    vector<unsigned int>                results_vec;

    sc_time start_time;

    std::string model_dir;
    std::string weights_dir;
    std::string test_dir;
    std::string output_dir;

    bool first;
    bool timed_out;
    unsigned num_images;

}; //SC_MODULE(tb)




