///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "stratus_hls.h"

#include <iostream>

template < typename DT, unsigned NO, unsigned NI, unsigned WS > class weight_struct
{
    public:

    DT weights[NO][NI][WS][WS];


    weight_struct()
    {
        HLS_FLATTEN_ARRAY(weights);
    }

    void set(const weight_struct& wx)
    {
        for (unsigned i=0; i<NO; i++){
            for (unsigned j=0; j<NI; j++){
                for (unsigned k=0; k<WS; k++){
                    for (unsigned l=0; l<WS; l++){
                        weights[i][j][k][l] = wx.weights[i][j][k][l];
                    }
                }
            }
        }
    }

    void operator = (const weight_struct& wx)
    {
        set(wx);
    }

    bool operator == (const weight_struct& wx)
    {
        bool eq = true;
        for (unsigned i=0; i<NO; i++){
            for (unsigned j=0; j<NI; j++){
                for (unsigned k=0; k<WS; k++){
                    for (unsigned l=0; l<WS; l++){
                        eq = eq && (weights[i][j][k][l]== wx.weights[i][j][k][l]);
                    }
                }
            }
        }
        return eq;
    }

};

template < typename DT, unsigned NO, unsigned NI, unsigned WS >
inline void sc_trace (sc_trace_file *tf, const weight_struct<DT,NO,NI,WS> & wx, const std::string& name)
{
    if(tf)
    {
        for (unsigned i=0; i<NO; i++){
            for (unsigned j=0; j<NI; j++){
                for (unsigned k=0; k<WS; k++){
                    for (unsigned l=0; l<WS; l++){
                        char n[64];
                        sprintf(n, ".p_%i_%j_%k", i, j, k);
                        sc_trace(tf, wx.weights[i][j][k][l], name+std::string(n));
                    }
                }
            }
        }
    }
}

template < typename DT, unsigned NO, unsigned NI, unsigned WS >
inline ostream & operator << (ostream& os, const weight_struct<DT,NO,NI,WS> & wx)
{
#ifndef STRATUS
    os << "(";
    for (unsigned i=0; i<NO; i++){
        for (unsigned j=0; j<NI; j++){
            for (unsigned k=0; k<WS; k++){
                for (unsigned l=0; l<WS; l++){
                  // os << wx.weights[i][j][k][l] << " ";
                  os << "[o=" << i << ",i=" << j << ",h=" << k << ",w=" << l << "] = " << wx.weights[i][j][k][l] << " " << endl;
                }
            }
        }
    }
    os << ")";
#endif
    return os;
}

// Read from an input stream. 
template < typename DT, unsigned NO, unsigned NI, unsigned WS >
inline istream & operator >> (istream& is, weight_struct<DT,NO,NI,WS> & wx)
{
    // The stream is assumed to have the weight matrix organized in output-major format.

    unsigned i, j, k, l;
    double val;
    for (i=0; (i<NO) && !(is.eof()); i++){
        for (j=0; (j<NI) && !(is.eof()); j++){
            for (k=0; (k<WS) && !(is.eof()); k++){
                for (l=0; (l<WS) && !(is.eof()); l++){
                    is >> val;
                    if (!is.fail()) {
                        wx.weights[i][j][k][l] = val;
                    }
                    is >> std::ws;
                }
            }
        }
    }
    if (!((i == NO) && (j == NI) && (k == WS) && (l == WS)))
    {
        // incomplete set read from stream
        cout << "Warning: partial weight vector in input file, got "
             << (i*j*k*l)
             << " value(s), expected "
             << ((NO)*(NI)*(WS)*(WS))
             << endl;
    }
    return is;
}
