///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "settings.h"

#include "cynw_p2p.h"
#include "array_mac.h"

template <typename SETTINGS, typename LINEBUFFER_PORT >
class conv2d : public sc_module
{
public:
    // typedefs/constants from settings class
    typedef typename SETTINGS::DT_SIZE   size_type;

    typedef typename SETTINGS::DT_BIASVAL    biasval_type;
    typedef typename SETTINGS::DT_WEIGHTVAL  weightval_type;

    typedef typename SETTINGS::DT_BIAS   bias_type;
    typedef typename SETTINGS::DT_WEIGHT weight_type;

    typedef typename SETTINGS::DT_INVAL  inval_type;
    typedef typename SETTINGS::DT_OUTVAL outval_type;

    typedef typename SETTINGS::DT_INPUT  input_type;
    typedef typename SETTINGS::DT_OUTPUT output_type;

    static const unsigned SIZE_WS = SETTINGS::SIZE_WS;
    static const unsigned SIZE_WS_SQ = (SIZE_WS*SIZE_WS);
    static const unsigned SIZE_RATIO = SETTINGS::SIZE_RATIO;
    static const unsigned NUM_IN = SETTINGS::NUM_IN;
    static const unsigned NUM_OUT = SETTINGS::NUM_OUT;

    SC_HAS_PROCESS(conv2d);

    // reset and clock are required ports
    sc_in < bool >   rst;
    sc_in_clk        clk;

    // stable inputs for image sizes
    sc_in < size_type > x_size;
    sc_in < size_type > y_size;

    // p2p input for weights
    typename cynw_p2p < weight_type, ioConfig >::in w;

    // p2p input for bias
    typename cynw_p2p < bias_type, ioConfig >::in   b;

    // line buffer input, cynw_p2p output
    typedef LINEBUFFER_PORT                                  in_port_type;
    typedef typename cynw_p2p < output_type, ioConfig >::out out_port_type;

    in_port_type in;
    out_port_type out;

    // constructor
    conv2d( sc_module_name name =
            sc_module_name( sc_gen_unique_name("conv2d") ) )
        : sc_module(name)
        , rst("rst")
        , clk("clk")
        , x_size("x_size")
        , y_size("y_size")
        , w("w")
        , b("b")
        , in("in")
        , out("out")
        {

            SC_CTHREAD(conv2d_thread, clk.pos());
            set_stack_size(0x10000000);
            reset_signal_is(rst, false);

            in.clk_rst(clk, rst);
            out.clk_rst(clk, rst);
            w.clk_rst(clk, rst);
            b.clk_rst(clk, rst);
        }

    // main thread
    void conv2d_thread()
        {
            // reset the interfaces
            {
                HLS_DEFINE_PROTOCOL("reset");
                out.reset();
                in.reset();
                w.reset();
                b.reset();
                wait();
            }

            // read bias values before starting main loop.
            bias_type b_conv = b.get();

            while (true)
            {
                HLS_ASSUME_STABLE(x_size);
                HLS_ASSUME_STABLE(y_size);

                input_type workingSet[SIZE_WS][SIZE_WS];

                in.set_size(y_size.read()/(SIZE_RATIO), x_size.read()/(SIZE_RATIO));

                in.start_tx();
                while (!in.y_done())
                {
                    while (!in.x_done())
                    {

                        output_type newOutput;
                        //
                        //  Read the input data
                        //
                        in.get(workingSet);
                        //
                        //  do the convolution filter(s).
                        //
                        newOutput = convolution(workingSet, b_conv);
                        //
                        //  Output data
                        //
                        out.put(newOutput);


                    }
                    // Define stride of 1
                    in.next_y();
                }
                in.end_tx();
            }
        }

    // the convolution filter function
    const output_type convolution(const input_type workingSet[SIZE_WS][SIZE_WS], const bias_type &b_conv)
        {

            outval_type sum_r;
            const outval_type zero = 0;
            output_type result;

            // loop over output channels
            for (int op = 0; op < NUM_OUT; op++)
            {
                HLS_UNROLL_LOOP(OFF, "output loop");
                // Different latency constraints for performance trade-offs.
#if defined(FAST)
                HLS_CONSTRAIN_LATENCY(0, HLS_ACHIEVABLE, "convolution_latency_fast");
#elif defined(MEDIUM)
                HLS_CONSTRAIN_LATENCY(0, NUM_IN+2, "convolution_latency_medium");
#else
                // unconstrained, only report the latency
                HLS_CONSTRAIN_LATENCY("convolution_latency_slow");
#endif

                // Convolution filter weights, one set for each output channel
                weight_type w_conv = w.get();

                sum_r = 0;

                // make 1-d local copies of the weights and inputs
                // arrays so we can use the array_mac function.

                const unsigned MAC_SIZE = (NUM_IN * SIZE_WS * SIZE_WS);
                inval_type in1[MAC_SIZE];
                weightval_type in2[MAC_SIZE];

                unsigned idx = 0;
                // loop over input channels
                for (int ip = 0; ip < NUM_IN; ip++)
                {
                    for (int i = 0; i < SIZE_WS; i++)
                    {
                        for (int j = 0; j < SIZE_WS; j++)
                        {
                            in1[idx] = workingSet[i][j][ip];
                            in2[idx] = w_conv.weights[0][ip][i][j];
                            idx++;
                        }
                    }

                }
                // multiply and accumulate
                sum_r = array_mac<MAC_SIZE, outval_type, inval_type, weightval_type>::mac(in1, in2);

                // add bias
                sum_r += b_conv.bias[op];

                // relu activation function
                result.p[op] = ((sum_r > zero) ? sum_r : zero);
            }


            return result;
        }


};

