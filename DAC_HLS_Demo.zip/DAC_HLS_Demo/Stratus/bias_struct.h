
///////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2019 Cadence Design Systems, Inc. All rights reserved worldwide.
//
// The code contained herein is the proprietary and confidential information
// of Cadence or its licensors, and is supplied subject to a previously
// executed license and maintenance agreement between Cadence and customer.
// This code is intended for use with Cadence high-level synthesis tools and
// may not be used with other high-level synthesis tools. Permission is only
// granted to distribute the code as indicated. Cadence grants permission for
// customer to distribute a copy of this code to any partner to aid in designing
// or verifying the customer's intellectual property, as long as such
// distribution includes a restriction of no additional distributions from the
// partner, unless the partner receives permission directly from Cadence.
//
// ALL CODE FURNISHED BY CADENCE IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
// KIND, AND CADENCE SPECIFICALLY DISCLAIMS ANY WARRANTY OF NONINFRINGEMENT,
// FITNESS FOR A PARTICULAR PURPOSE OR MERCHANTABILITY. CADENCE SHALL NOT BE
// LIABLE FOR ANY COSTS OF PROCUREMENT OF SUBSTITUTES, LOSS OF PROFITS,
// INTERRUPTION OF BUSINESS, OR FOR ANY OTHER SPECIAL, CONSEQUENTIAL OR
// INCIDENTAL DAMAGES, HOWEVER CAUSED, WHETHER FOR BREACH OF WARRANTY,
// CONTRACT, TORT, NEGLIGENCE, STRICT LIABILITY OR OTHERWISE.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#include "stratus_hls.h"


template < typename DT, unsigned S > class bias_struct
{
    public:
    DT bias[S];


    bias_struct()
    {
        HLS_FLATTEN_ARRAY(bias);
    }

    void set(const bias_struct& bx)
    {
        for (unsigned i=0; i<S; i++){
            bias[i] = bx.bias[i];
        }
    }

    void operator = (const bias_struct& bx)
    {
        set(bx);
    }

    bool operator == (const bias_struct& bx)
    {
        bool eq = true;
        for (unsigned i=0; i<S; i++){
            eq = eq && (bias[i]== bx.bias[i]);
        }
        return eq;
    }

};

template < typename DT, unsigned S >
inline void sc_trace (sc_trace_file *tf, const bias_struct<DT,S> & bx, const std::string& name)
{
    if(tf)
    {
        for (unsigned i=0; i<S; i++){
                    char n[64];
                    sprintf(n, ".p_%i", i);
                    sc_trace(tf, bx.bias[i], name+std::string(n));
        }
    }
}

template < typename DT, unsigned S >
inline ostream & operator << (ostream& os, const bias_struct<DT,S> & bx)
{
#ifndef STRATUS
    os << "(";
    for (unsigned i=0; i<S; i++){
      // os << bx.bias[i] << " ";
      os << "[" << i << "] = " << bx.bias[i] << endl; 
    }
    os << ")";
#endif
    return os;
}

// Read from an input stream. 
template < typename DT, unsigned S >
inline istream & operator >> (istream& is, bias_struct<DT,S> & bx)
{
    unsigned i;
    double val;
    for (i=0; (i<S) && !(is.eof()); i++){
      is >> val;
      if (!is.fail()) {
        bx.bias[i] = val;
      }
      is >> std::ws;
    }
    if (!(i == S))
    {
        // incomplete set read from stream
        cout << "Warning: partial bias vector in input file, got "
             << (i)
             << " value(s), expected "
             << (S)
             << endl;
    }
    return is;
}
